package com.neosoft.SpringBootApplication.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.Date;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name= "user_master_tab")
public class UserMaster {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_master_id")
    private int userMasterId;


    @NotNull(message = "FirstName required.")
    @Size(min = 2, max = 50, message = "The length of FirstName must be between 2 and 50 characters.")
    private String firstName;

    @NotNull(message = "LastName required.")
    @Size(min = 2, max = 50, message = "The length of lastName must be min2 & max 50 characters.")
    private String lastName;

    @NotNull(message = "FatherName is required.")
    @Size(min = 2, max = 50, message = "The length of FatherName Should be 2 and 50 characters.")
    private String fatherName;

    @NotNull(message = "MotherName is required.")
    @Size(min = 2, max = 50, message = "length of FatherName Should be between 2 and 50 characters.")
    private String motherName;

    @NotNull(message = "Department name is required.")
    private String department;

    @NotNull(message = "dob can not be null")
    @Past(message = "The date of birth must be in the past.")
    private Date dob;

    @NotNull(message = "Email  can not be null")
    @Email(regexp = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}",flags = Pattern.Flag.CASE_INSENSITIVE)
    private String emailId;
/*
    @NotNull(message = "Please enter salary")
    @Min(value=1000, message = "Salary must be atleast 1000.00")
    @Max(value=10000, message = "Salary should not be greater than 10000.00")
    private Integer monthlyIncome;*/

    @OneToMany( cascade = CascadeType.ALL)
    @JoinColumn(name = "contact_id")
    @NotNull
    @Valid
    private List<UserContact> userContexts;

    @OneToOne(cascade= CascadeType.ALL)
    @JoinColumn(name ="user_id")
    @NotNull
    @Valid
    private User user;

}
