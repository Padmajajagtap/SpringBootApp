package com.neosoft.SpringBootApplication.controller;

import com.neosoft.SpringBootApplication.entity.UserMaster;
import com.neosoft.SpringBootApplication.model.UserRequest;
import com.neosoft.SpringBootApplication.model.UserResponse;
import com.neosoft.SpringBootApplication.repo.UserMasterRepository;
import com.neosoft.SpringBootApplication.service.IUserService;
import com.neosoft.SpringBootApplication.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private IUserService userService;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	UserMasterRepository userMasterRepository;

	/*@PostMapping("/save")
	public ResponseEntity<?> registerUser(@Valid @RequestBody UserMaster userMaster){

		if ( userMasterRepository.existsByfirstName(userMaster.getLastName()))
		{
			return new ResponseEntity<>("User is already exists !!! Unable to create same User... ", HttpStatus.BAD_REQUEST);
		}
		         userService.saveUserData(userMaster);
		return new ResponseEntity<>("User registered successfully !!!",HttpStatus.CREATED);
	}
*/
	@PostMapping("/save")
	public ResponseEntity<Object> saveUserData(@Valid  @RequestBody UserMaster userMaster){
		if(userMasterRepository.existsByemailId(userMaster.getEmailId())){
			return new ResponseEntity<>("Data is already exists!", HttpStatus.BAD_REQUEST);
		}
		userService.saveUserData(userMaster);
		return new ResponseEntity<>("Data Saved!", HttpStatus.OK);
	}

	@PostMapping("/login")
	public ResponseEntity<UserResponse>  loginUser(@Valid @RequestBody UserRequest userRequest) throws Exception{
		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(
							userRequest.getUsername(),
							userRequest.getPassword()
					));
		}catch (Exception exception){
			throw new Exception("Invalid Username & Password");
		}
		String token = jwtUtil.generateToken(userRequest.getUsername());
		return ResponseEntity.ok(
				new UserResponse(token, " Successfully Generated !"));
	}


	@GetMapping("/users")
	public List<UserMaster> getAllData(){
		return userService.findAllUserData();
	}


	@GetMapping("/get/{userMasterId}")
	public UserMaster fetchUserById(@PathVariable("userMasterId") int userMasterId){

		return userService.findUserById(userMasterId);
	}

	@GetMapping("/search")
	public ResponseEntity<List<UserMaster>> searchUserMaster(@RequestParam("query") String query){
		return ResponseEntity.ok(userService.searchUserMaster(query));
	}


}
