package com.neosoft.userapppocjwttoken;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAppPocJwtTokenApplicationTests {

    @Test
    void contextLoads() {
    }

}
